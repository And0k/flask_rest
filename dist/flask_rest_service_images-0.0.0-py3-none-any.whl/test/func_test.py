#! /usr/bin/env python
# -*- coding: utf-8 -*-
"""
  Purpose:  functional tests
  Author:   Andrey Korzh <ao.korzh@gmail.com>
  Created:  25.01.2019
"""
import pytest
from flask import url_for
from PIL import Image
from io import BytesIO

url_images = ['https://www.google.com/images/branding/googlelogo/2x/googlelogo_color_272x92dp.png',
             'http://flask.pocoo.org/docs/1.0/_images/logo-full.png']


#@pytest.mark.skip(reason="not now")
def test_post_task(client, tmp_processed_dir_path, list_result_dirs):
    """
    http post: send urls for processing
    check: images from urls are processed and saved in new folder named with generated GUID which is returned
    :param client: fixture, injected by the `pytest-flask` plugin
    :param tmp_processed_dir_path: fixture, using it ensures we have new temporary dir
    :return:
    """

    # query
    n_urls = len(url_images)
    response = client.post("/", json = {'url_list': url_images, 'threshold': 150})

    # Was 1 dir created?
    assert len(list_result_dirs()) == 1

    # Was it filled with files number equal number of queried urls?
    assert len([1 for _ in list_result_dirs()[0].iterdir()]) == n_urls

    # Validate the response
    assert response.status_code == 201
    assert response.json == {
        'guid': list_result_dirs()[0].name,
        'processed_cnt': n_urls
    }


@pytest.fixture
def guids(list_result_dirs):
    """
    work folders from file system (autonamed folders has guid names)
    :param list_result_dirs: fixture
    :return:
    """
    ids = [d.name for d in list_result_dirs()]
    assert len(ids)>0  # test folder prepared?
    return ids


@pytest.mark.parametrize('url', ['', '/', '/index', '/index/'])
def test_get_json_ids_list(client, url, guids):
    """
    http get any of parametrized urls
    receive same list of work folders in json
    :param client: fixture, injected by the `pytest-flask` plugin
    :return:
    """
    response = client.get(url)
    # receive json with work ids?
    assert response.status_code == 200
    assert response.json == {'guids': guids}


i_dir = 0    #index of folder we check
i_file = 1   #index of file we check

@pytest.mark.parametrize('i_dir', [0])
def test_get_json_files_list(client, app, list_result_dirs, guids, i_dir):
    """
    http get address of urls list of (processed) files for one of ids
    receive list contents of corresponding folder with urls relative to address for Config['PROCESSED_DIR_PATH']
    :param guids: work folders red from file system
    :global param: i_dir
    """
    response = client.get(f"/{guids[i_dir]}")
    assert response.status_code == 200
    # receive json with urls of result files?
    assert response.json == {
        'files': [url_for('static', filename=str(file.relative_to(app.config['PROCESSED_DIR_PATH']))) for file in \
                  list_result_dirs()[i_dir].iterdir()
                  ]
    }


def test_get_file(client, app, guids):
    """
    http get address of 1 (processed) file for one of ids
    receive 1 file of Config['PROCESSED_IMAGE_FORMAT'] format
    :global param: i_dir, i_file
    """
    response = client.get(f"/{guids[i_dir]}/{i_file}.{app.config['PROCESSED_IMAGE_FORMAT']}/")
    assert response.status_code == 200
    img = Image.open(BytesIO(response.data))
    assert img.format == app.config['PROCESSED_IMAGE_FORMAT'].upper()


@pytest.fixture(params=range(4), ids= ['""', '/', '/guid', '/guid/file']) #
def query_urls(request, app, guids):
    check_urls = ['',
                  '/',
                  f'/{guids[i_dir]}',
                  f"/{guids[i_dir]}/{i_file}.{app.config['PROCESSED_IMAGE_FORMAT']}"]
    response_contains = [
        guids[i_dir],
        guids[i_dir],
        f"/{guids[i_dir]}/{i_file}.{app.config['PROCESSED_IMAGE_FORMAT']}",  #[f.name for f in list_result_dirs()[i_dir].iterdir()][i_file],  # or list_result_dirs()[i_dir] /
        'PNG']
    return ((check_urls[request.param], response_contains[request.param]),)


def test_get_html(client, app, query_urls):
    """
    Check content negotiation. Http get queries with {'Accept': 'text/html'}
    receive from {'Accept': 'text/html'} queries has html result
    :param headers:
    :return:
    """
    url, response_contains = query_urls[0]
    headers = 'text/html'  # 'headers', ['text/html']
    response = client.get(url, headers={'Accept': headers})
    assert response_contains.encode() in response.data
    if url.strip('/').endswith(app.config['PROCESSED_IMAGE_FORMAT']):
        assert response.mimetype.startswith('image')
    else:
        assert response.mimetype == headers


def test_delete(client, tmp_processed_dir_path, list_result_dirs):
    """

    :param client:
    :param tmp_processed_dir_path: fixture, using it ensures we have new temporary dir
    :return:
    """
    # make some dir inside temorary dir and write file
    new_dir = (tmp_processed_dir_path / '~test_id_to_delete~')
    new_dir.mkdir()
    (new_dir / 'somefile').touch()
    # Was 1 dir created?
    assert len(list_result_dirs()) == 1

    # query to delete dir
    response = client.delete(f"/{new_dir.name}")

    # Was dir deleted?
    assert len(list_result_dirs()) == 0

    # Validate the response
    assert response.status_code == 204
    # assert response.json == {
    #     'guid': list_result_dirs()[0].name,
    #     'processed_cnt': 2
    # }
    pass

def test_update_task(client, tmp_processed_dir_path, list_result_dirs):
    """
    http post: send urls for processing
    check: images from urls are processed and saved in new folder named with generated GUID which is returned
    :param client: fixture, injected by the `pytest-flask` plugin
    :param tmp_processed_dir_path: fixture, using it ensures we have new temporary dir
    :return:
    """

    # make some dir inside temorary dir and write file
    new_dir = (tmp_processed_dir_path / '~test_id_to_delete~')
    new_dir.mkdir()
    (new_dir / 'somefile').touch()
    # Was 1 dir created?
    assert len(list_result_dirs()) == 1

    # query to update dir
    n_urls = len(url_images)
    response = client.put(f"/{new_dir.name}", json = {'url_list': url_images, 'threshold': 150})

    # same dir exists?
    assert list_result_dirs()[0] == new_dir

    # Was it filled with files number equal number of queried urls?
    assert len([1 for _ in list_result_dirs()[0].iterdir()]) == n_urls

    # Validate the response
    assert response.status_code == 201
    assert response.json == {
        'guid': list_result_dirs()[0].name,
        'processed_cnt': n_urls
    }


@pytest.mark.skip(reason="run only if need print your API as a Postman")
def postman_helper(app):
    from flask import json
    urlvars = False     # Build query strings in URLs
    swagger = True      # Export Swagger specifications
    data = app.as_postman(urlvars=urlvars, swagger=swagger)
    print(json.dumps(data))