from . import create_app
from .apis import api
import logging
log = logging.getLogger(__name__)

app = create_app()
api.init_app(app)


if __name__ == '__main__':
    log.info(
        '>>>>> Starting Serving at http://{}/ >>>>>'.format(app.config['SERVER_NAME'])
    )
    app.run(port=5000, debug=__debug__)