"""
default config for the factory
"""
from pathlib import Path
import logging


class Config:
    DEBUG = __debug__                   # Turns on/off debugging features in Flask
    PROCESSED_DIR_PATH = Path('data')   # static_folder
    PROCESSED_IMAGE_FORMAT = 'png'
    LOG_PATH = Path('server.log')
    LOGGING_LEVEL = logging.INFO
